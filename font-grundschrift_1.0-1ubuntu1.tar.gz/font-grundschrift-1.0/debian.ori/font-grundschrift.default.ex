# Defaults for font-grundschrift initscript
# sourced by /etc/init.d/font-grundschrift
# installed at /etc/default/font-grundschrift by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
