?package(font-grundschrift):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="font-grundschrift" command="/usr/bin/font-grundschrift"
